<template>
    <div>
        <div class="text-center pt-4">
            Hola {{hola}}
        </div>
    </div>
</template>
<script>
export default {
    data()
    {
        return {
            hola: 'Mundo'
        }
    }
}
</script>
